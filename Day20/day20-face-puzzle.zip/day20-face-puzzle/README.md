# Day 20 — Face Puzzle Game 🧩
### #ABTalks60DayClaudeChallenge

A browser-based puzzle game that captures your face via webcam and turns it into a sliding/swap puzzle (3×3, 4×4, or 5×5). Built as a single self-contained HTML file — no backend, no build step, no dependencies.

🔗 **Live file:** open `index.html` in any modern browser (or enable GitHub Pages on this repo for a hosted link).

---

## ✨ Features

- **Webcam capture** — requests camera permission, live preview, snapshot to canvas
- **3 difficulty levels** — 3×3 (easy), 4×4 (medium), 5×5 (hard)
- **Drag & touch controls** — full mouse drag support on desktop, native touch events on mobile/tablet
- **Smart visual feedback** — pink glow border while dragging, green border on correctly placed pieces
- **Live stats** — mm:ss.t timer, move counter, pieces-placed counter
- **Auto win detection** — stops timer instantly, shows results overlay
- **Persistent leaderboard** — top 5 best times saved to `localStorage` (date, time, moves, difficulty)
- **Fully responsive** — works on desktop, tablet, and mobile; recalculates layout on resize
- **Graceful camera error handling** — permission denied, no camera found, camera in use

## 🛠️ Tech Stack

Pure vanilla JavaScript, HTML5, and CSS3. No frameworks, no external libraries.

| Browser API | Used for |
|---|---|
| `navigator.mediaDevices.getUserMedia` | Webcam access |
| `<canvas>` | Photo capture / cropping |
| `localStorage` | Leaderboard persistence |
| Pointer + Touch events | Drag-and-drop piece movement |

## 🚀 How to Run

1. Clone this repo
2. Open `index.html` directly in Chrome, Firefox, or Safari
   - **Important:** camera access requires `https://` or `localhost` — it will NOT work if opened via `file://` in some browsers. Easiest fix: serve it locally:
     ```bash
     python3 -m http.server 8000
     # then visit http://localhost:8000
     ```
   - Or just enable **GitHub Pages** on this repo (Settings → Pages → deploy from main branch) and open the hosted HTTPS URL.

## 🎮 How to Play

1. Allow camera access → click **Take Photo**
2. Pick a difficulty (3×3 / 4×4 / 5×5) → **Start Puzzle**
3. Drag pieces (mouse or touch) to swap them into the correct spot
4. Watch the timer, move counter, and "pieces placed" tracker live
5. Solve it → see your results + check the leaderboard
6. **Play Again**, **Reshuffle**, or **New Photo** to go again

## 🧠 What I Learned / Built (Day 20 of 60)

- Slicing an image into a grid using `background-position` + `background-size` instead of pre-cutting image files
- Building a solvable shuffle (since any-to-any piece swapping means every permutation is solvable, no parity checks needed — unlike a classic 15-puzzle)
- Unifying mouse and touch drag handling into one consistent interaction model
- Handling `getUserMedia` permission/error states gracefully across browsers
- Using `localStorage` to persist a sorted, capped leaderboard
- Responsive canvas/grid recalculation on window resize without breaking in-progress puzzle state

## 📂 Files

```
day20-face-puzzle/
├── index.html      # complete game (HTML + CSS + JS, single file)
└── README.md        # this file
```

## 🔗 Part of the ABTalks 60-Day Claude AI Mastery Challenge

Building one reusable AI/dev skill in public every day. Follow the series on [LinkedIn] and the full archive on [GitHub: sidharth0018].

---

*Day 20 of 60 — building in public, one puzzle piece at a time.* 🧩
