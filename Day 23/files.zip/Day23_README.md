# Day 23 — AI Startup Validation & MVP Advisor 🚜📊

> Part of the **#ABTalks60DayChallenge** — 60 Days of building with Claude AI.
> One project a day. Today: an AI advisor that turns a raw startup idea into a VC-style validation report **and** a buildable MVP blueprint — entirely through structured conversation with Claude, no manual research.

---

## 🎯 What this project does

I asked Claude to act as a **Startup Advisor / VC Analyst / Market Research Expert**, fed it a one-line startup idea (a farm equipment rental marketplace for small Indian farmers), and asked it to validate it properly — the way an analyst or a YC partner would, not the way a hype generator would.

The output was two consulting-grade documents, generated end-to-end by Claude using live web search + code execution:

| Document | What it contains | Pages |
|---|---|---|
| **Startup Validation Report** | Executive summary, Problem Validation, Founder-Market Fit score, TAM/SAM/SOM, Competitor Analysis, Market Gap Analysis, ICP, Buyer Persona, Risk Assessment, Go/No-Go verdict, 30-Day Action Plan | 18 |
| **Customer & MVP Blueprint** | ICP, Buyer Persona, Top 10 Pain Points, Customer Journey, Objections & Triggers, MVP Recommendation, MoSCoW prioritization, Pricing Hypothesis, Top 5 Risks, Founder Action Sheet, Scorecard, Final Verdict | 4 |

Both are real `.docx` + `.pdf` files, with tables, color-coded scorecards, and matplotlib-generated charts — built with code, not copy-pasted into a template.

---

## 🧠 The idea being validated

**Farm Equipment Rental Platform** — a mobile marketplace connecting small Indian farmers (who can't afford to own tractors/harvesters) with equipment owners who have idle machinery, modeled loosely on "Uber for tractors."

This is a **real idea I'm genuinely evaluating**, not a toy example — which is why the honesty of the verdict mattered more than how impressive it sounded.

---

## 🔑 Key outputs / verdict

| Metric | Result |
|---|---|
| Problem Validation | **8 / 10** — strongly validated by public agriculture-census data |
| Founder-Market Fit | **3.6 / 10** — weak: no domain network, zero existing validation yet |
| TAM (India, illustrative) | ~$4.6–4.9 Bn GTV (bottom-up estimate) |
| SOM (Year 3, realistic) | ~$22–28 Mn GTV |
| Competitive intensity | **High** — Mahindra-backed Trringo, VC-funded EM3, free govt. CHCs already serve this exact customer |
| Validation Report verdict | 🟡 **Conditional Go** — validate before building |
| MVP Blueprint verdict | 🟡 **Promising but Unvalidated** |

**The single biggest insight:** this is *not* a blank-ocean market. A generic "rental app" loses to an OEM-backed incumbent and a free government alternative. The only credible path is a narrow, hyperlocal wedge (single district, WhatsApp/voice-first booking, verified operators) — validated with real farmer conversations *before* writing a line of app code.

---

## 🏗️ How it was built

1. **Conversational discovery** — Claude asked for the 7 standard VC-intake questions (idea, problem, target customer, motivation, existing validation, market, ambition level) before generating anything.
2. **Live web research** — Claude used real-time web search to pull actual market-size figures (IMARC, Precedence Research, Mordor Intelligence, Fact.MR) and India-specific agriculture census data (NSSO, Agriculture Census 2015–16) rather than guessing numbers.
3. **Bottom-up estimation with transparent assumptions** — since no public report isolates an India-only rental GTV figure, Claude built a TAM/SAM/SOM model from farm-count × spend assumptions and *explicitly flagged it as a hypothesis to validate*, not a fact.
4. **Code-generated documents** — Word docs were built programmatically with the `docx` npm library (tables, color-coded scorecards, headers/footers with page numbers), and charts were rendered with `matplotlib` and embedded as images. Final files were converted to PDF via LibreOffice headless and validated before delivery.
5. **Follow-up extraction** — in a later turn, Claude was handed its *own* earlier report as a `.docx` upload and asked to extract the idea/problem/competitors/insights from it — testing whether it could correctly parse and reuse its own structured output as input to a new document.

---

## 📂 Repo contents

```
Day23-Startup-Validation-AI-Advisor/
├── README.md                              ← you are here
├── LEARNINGS.md                           ← what worked, what I'd change
├── scripts/
│   ├── 01_generate_validation_report.js   ← docx-js build script, 18-page report
│   ├── 02_validation_report_charts.py     ← matplotlib charts (TAM/SAM/SOM, FMF, market trend)
│   ├── 03_generate_mvp_blueprint.js       ← docx-js build script, 4-page blueprint
│   └── 04_mvp_blueprint_charts.py         ← matplotlib scorecard chart
├── outputs/
│   ├── Startup_Validation_Report.pdf
│   └── Customer_MVP_Blueprint.pdf
└── docs/
    ├── sample_report_cover.jpg
    ├── sample_blueprint_page1.jpg
    └── sample_blueprint_scores.jpg
```

---

## ▶️ How to reproduce

```bash
# 1. Install dependencies
npm install -g docx
pip install matplotlib --break-system-packages

# 2. Generate the charts first (scripts read/write PNGs in the working directory)
python3 scripts/02_validation_report_charts.py
python3 scripts/04_mvp_blueprint_charts.py

# 3. Generate the Word documents
node scripts/01_generate_validation_report.js
node scripts/03_generate_mvp_blueprint.js

# 4. (Optional) Convert to PDF with LibreOffice headless
soffice --headless --convert-to pdf Startup_Validation_Report.docx
soffice --headless --convert-to pdf Customer_MVP_Blueprint.docx
```

---

## 🏷️ Tags

`#BuildInPublic` `#ABTalks60DayChallenge` `#ClaudeAI` `#StartupValidation` `#AgriTech` `#MVP` `#AIProductManagement`

---

**Day 23 of 60 — one idea validated honestly is worth more than ten validated optimistically.**
