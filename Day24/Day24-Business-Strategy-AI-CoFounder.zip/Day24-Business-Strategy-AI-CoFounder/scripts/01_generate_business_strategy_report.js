const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel, BorderStyle,
  WidthType, ShadingType, VerticalAlign, PageNumber, ImageRun, TableOfContents, TabStopType
} = require('docx');
const fs = require('fs');

const NAVY="1F3A5F", NAVY_DARK="14263F", GOLD="C9A24B", GREY="6B7280", LIGHT="EEF2F7", RED="B3463A", GREEN="3D7A5C", WHITE="FFFFFF", TEXT="2A2A2A";
const FONT="Arial";
const PAGE_W=12240, PAGE_H=15840, MARGIN=1080;

const border=(c="D9DEE6",s=2)=>({style:BorderStyle.SINGLE,size:s,color:c});
const cellBorders=(c="D9DEE6")=>({top:border(c),bottom:border(c),left:border(c),right:border(c)});

function h1(text, num){
  return new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore:true, spacing:{before:0,after:200},
    border:{bottom:{style:BorderStyle.SINGLE,size:6,color:GOLD,space:4}},
    children:[ new TextRun({text:num?`${num}.  `:"", bold:true, color:GOLD, size:32, font:FONT}), new TextRun({text, bold:true, color:NAVY, size:32, font:FONT}) ] });
}
function h2(text){
  return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing:{before:280,after:140},
    children:[ new TextRun({text, bold:true, color:NAVY, size:24, font:FONT}) ] });
}
function p(text, opts={}){
  return new Paragraph({ spacing:{before:opts.before??60, after:opts.after??120, line:276},
    children:[ new TextRun({text, size:21, color:TEXT, font:FONT, italics:opts.italic, bold:opts.bold}) ] });
}
function bullet(text, opts={}){
  return new Paragraph({ numbering:{reference:"bullets", level:opts.level||0}, spacing:{before:40,after:40,line:268},
    children:[ new TextRun({text, size:20, color:TEXT, font:FONT, bold:opts.bold}) ] });
}
function tag(text, color, fg=WHITE){
  return new Paragraph({ spacing:{before:40,after:160},
    children:[ new TextRun({text:`  ${text}  `, bold:true, size:18, color:fg, font:FONT, shading:{type:ShadingType.CLEAR, fill:color}}) ] });
}
function caption(text){
  return new Paragraph({ spacing:{before:40,after:200}, alignment:AlignmentType.CENTER,
    children:[ new TextRun({text, italics:true, size:17, color:GREY, font:FONT}) ] });
}
function headerCell(text,width,opts={}){
  return new TableCell({ width:{size:width,type:WidthType.DXA}, borders:cellBorders(NAVY),
    shading:{type:ShadingType.CLEAR, fill:NAVY}, margins:{top:90,bottom:90,left:130,right:130},
    verticalAlign:VerticalAlign.CENTER, columnSpan:opts.span,
    children:[ new Paragraph({alignment:opts.align||AlignmentType.LEFT,
      children:[new TextRun({text, bold:true, size:18, color:WHITE, font:FONT})]}) ] });
}
function bodyCell(text,width,opts={}){
  return new TableCell({ width:{size:width,type:WidthType.DXA}, borders:cellBorders(),
    shading:{type:ShadingType.CLEAR, fill:opts.fill||(opts.zebra?LIGHT:WHITE)},
    margins:{top:90,bottom:90,left:130,right:130}, verticalAlign:VerticalAlign.CENTER, columnSpan:opts.span,
    children:(Array.isArray(text)?text:[text]).map(t=> new Paragraph({alignment:opts.align||AlignmentType.LEFT, spacing:{after:opts.multiline?40:0},
      children:[new TextRun({text:t, size:18, color:opts.color||TEXT, font:FONT, bold:opts.bold})]})) });
}
function table(widths, rows){ return new Table({ width:{size:widths.reduce((a,b)=>a+b,0),type:WidthType.DXA}, columnWidths:widths, rows }); }
function img(path,w,h){
  return new Paragraph({alignment:AlignmentType.CENTER, spacing:{before:160,after:60}, children:[
    new ImageRun({type:"png", data:fs.readFileSync(path), transformation:{width:w,height:h},
      altText:{title:"img",description:"img",name:"img"}}) ]});
}

const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT, size: 21, color: TEXT } } },
    paragraphStyles: [
      { id:"Heading1", name:"Heading 1", basedOn:"Normal", next:"Normal", quickFormat:true,
        run:{size:32,bold:true,font:FONT,color:NAVY}, paragraph:{spacing:{before:240,after:200}, outlineLevel:0} },
      { id:"Heading2", name:"Heading 2", basedOn:"Normal", next:"Normal", quickFormat:true,
        run:{size:24,bold:true,font:FONT,color:NAVY}, paragraph:{spacing:{before:260,after:140}, outlineLevel:1} },
    ],
  },
  numbering: { config: [
    { reference:"bullets", levels:[
      { level:0, format:LevelFormat.BULLET, text:"\u2014", alignment:AlignmentType.LEFT,
        style:{paragraph:{indent:{left:360,hanging:240}}, run:{color:GOLD,bold:true}} },
    ]},
  ]},
  sections: [{
    properties: { page: { size:{width:PAGE_W,height:PAGE_H}, margin:{top:1260,right:MARGIN,bottom:1080,left:MARGIN} } },
    headers: { default: new Header({ children:[ new Paragraph({
      tabStops:[{type:TabStopType.RIGHT, position:PAGE_W-MARGIN*2}],
      border:{bottom:{style:BorderStyle.SINGLE,size:4,color:"C9C9C9",space:4}},
      children:[
        new TextRun({text:"BUSINESS STRATEGY REPORT", size:15, color:GREY, font:FONT, bold:true}),
        new TextRun({text:"\tFarm Equipment Rental Platform \u2014 India", size:15, color:GREY, font:FONT}),
      ]})]}) },
    footers: { default: new Footer({ children:[ new Paragraph({
      tabStops:[{type:TabStopType.RIGHT, position:PAGE_W-MARGIN*2}],
      children:[
        new TextRun({text:"Confidential \u2014 Built on Day 23 Customer & MVP Blueprint", size:15, color:GREY, font:FONT}),
        new TextRun({text:"\tPage ", size:15, color:GREY, font:FONT}),
        new TextRun({children:[PageNumber.CURRENT], size:15, color:GREY, font:FONT}),
        new TextRun({text:" of ", size:15, color:GREY, font:FONT}),
        new TextRun({children:[PageNumber.TOTAL_PAGES], size:15, color:GREY, font:FONT}),
      ]})]}) },
    children: [

      // ---------------- COVER ----------------
      new Paragraph({ spacing:{before:1100}, children:[] }),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{after:80},
        children:[new TextRun({text:"BUSINESS STRATEGY & INVESTMENT REPORT", size:22, bold:true, color:GOLD, font:FONT})]}),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{after:320},
        children:[new TextRun({text:"Farm Equipment Rental Platform for Smallholder Farmers, India", size:44, bold:true, color:NAVY, font:FONT})]}),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{after:40},
        children:[new TextRun({text:"Can this become a sustainable, fundable business \u2014 not just a validated problem?", size:22, italics:true, color:GREY, font:FONT})]}),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{before:600, after:40},
        children:[new TextRun({text:"Prepared for: Sidh (Founder)", size:20, color:TEXT, font:FONT})]}),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{after:40},
        children:[new TextRun({text:"Prepared by: AI Co-Founder & Growth Strategy Desk", size:20, color:TEXT, font:FONT})]}),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{after:40},
        children:[new TextRun({text:"Source: Day 23 Customer & MVP Blueprint (June 22, 2026)", size:20, color:TEXT, font:FONT})]}),
      new Paragraph({ alignment:AlignmentType.CENTER, spacing:{before:500},
        children:[new TextRun({text:"Verdict: VALIDATE \u2014 Real Problem, Unproven Business Model", size:22, bold:true, color:NAVY_DARK, font:FONT,
          shading:{type:ShadingType.CLEAR, fill:GOLD}})]}),

      // ---------------- TOC ----------------
      new Paragraph({ pageBreakBefore:true, heading:HeadingLevel.HEADING_1, spacing:{after:200},
        children:[new TextRun({text:"Table of Contents", bold:true, size:32, color:NAVY, font:FONT})]}),
      new TableOfContents("Table of Contents", { hyperlink:true, headingStyleRange:"1-1" }),

      // ================= STARTUP SUMMARY =================
      h1("Startup Summary & Assumptions", null),
      h2("What this is, in 8 bullets"),
      bullet("A mobile/WhatsApp marketplace connecting India's 125M+ small/marginal farmers (renters) with equipment owners who have idle tractors and implements (supply)."),
      bullet("Core problem: farmers can't afford to own machinery; mechanization in India sits at ~40\u201347% vs 75\u201395% in comparable economies."),
      bullet("MVP is deliberately not an app: a WhatsApp/voice-call booking flow with a human dispatcher matching demand to listed supply in ONE district."),
      bullet("Monetization: 8\u201312% commission on each booking's transaction value, charged to the equipment owner, not the farmer."),
      bullet("Already-validated insight: the problem is real (Problem Severity 80/100), but Customer Clarity (55), PMF Potential (42), and MVP Readiness (38) are all unproven."),
      bullet("Direct competitors already exist: Trringo (Mahindra-backed), EM3 Agri Services (VC-funded), and free government Custom Hiring Centres (CHCs)."),
      bullet("Go-to-market is hyperlocal and human-powered: village agents and word-of-mouth, not paid digital acquisition."),
      bullet("Stated ambition: a real startup, not a side project \u2014 founder explicitly wants VC-scale impact, not a lifestyle business."),
      h2("Extracted assumptions"),
      table([2000,7080],[
        new TableRow({children:[headerCell("Dimension",2000), headerCell("Assumption as stated in the Blueprint",7080)]}),
        new TableRow({children:[bodyCell("Customer",2000,{zebra:true,bold:true}), bodyCell("Small/marginal farmer (demand) + medium farmer/contractor (supply); both reachable via WhatsApp/voice",7080,{zebra:true})]}),
        new TableRow({children:[bodyCell("MVP",2000,{bold:true}), bodyCell("Manual WhatsApp/call dispatch in one district; no app, no owned fleet at this stage",7080)]}),
        new TableRow({children:[bodyCell("Value proposition",2000,{zebra:true,bold:true}), bodyCell("Faster, more reliable, fairly-priced access to machinery than informal contractors; incremental income for idle-equipment owners",7080,{zebra:true})]}),
        new TableRow({children:[bodyCell("Pricing",2000,{bold:true}), bodyCell("8\u201312% commission, paid by the owner per completed booking \u2014 untested, 3 price points to be trialed",7080)]}),
        new TableRow({children:[bodyCell("Revenue model",2000,{zebra:true,bold:true}), bodyCell("Take-rate on Gross Transaction Value (GTV); no other stated revenue line",7080,{zebra:true})]}),
        new TableRow({children:[bodyCell("GTM",2000,{bold:true}), bodyCell("Village agents + word-of-mouth + district-first density, not paid acquisition or app-store discovery",7080)]}),
      ]),

      // ================= BUSINESS REALITY CHECK =================
      h1("Business Reality Check", "1"),
      table([2600,6480],[
        new TableRow({children:[headerCell("Question",2600), headerCell("Honest Answer",6480)]}),
        new TableRow({children:[bodyCell("Who pays?",2600,{zebra:true,bold:true}), bodyCell("The equipment owner pays the commission \u2014 not the farmer directly. Revenue exists only if owners keep transacting through the platform repeatedly.",6480,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Why do they pay?",2600,{bold:true}), bodyCell("Because the platform brings them demand (bookings) they would not otherwise reach \u2014 incremental income on an idle asset is the only reason to tolerate a fee.",6480,{multiline:true})]}),
        new TableRow({children:[bodyCell("How is it discovered?",2600,{zebra:true,bold:true}), bodyCell("Entirely offline-to-online: village agents and neighbor word-of-mouth. There is no stated digital acquisition channel \u2014 discovery is slow and hard to systematize at scale.",6480,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Biggest growth risk?",2600,{bold:true}), bodyCell("The model depends on a human dispatcher per district \u2014 this does not scale the way a self-serve app does. Growth requires hiring/training a dispatcher in every new district, one at a time.",6480,{multiline:true})]}),
        new TableRow({children:[bodyCell("Biggest monetization risk?",2600,{zebra:true,bold:true}), bodyCell("Disintermediation: once a farmer and an owner are matched once, nothing stops them from transacting directly next season to avoid the fee \u2014 the single largest threat to recurring revenue in this model.",6480,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Weakest assumptions to validate?",2600,{bold:true}), bodyCell(["Owners will tolerate an 8\u201312% fee rather than negotiate around the platform after the first match","Average per-farm rental spend (~\u20b94,000/yr) used in the TAM model","Dispatcher cost per booking is lower than commission earned per booking"],6480,{multiline:true})]}),
      ]),
      p("Net read: this is a real problem with a fragile revenue model. Every dollar of revenue depends on (a) owners not cutting the platform out after the first transaction, and (b) a manual dispatcher operation staying cheaper than what it earns \u2014 neither has been tested.", {italic:true}),

      // ================= EXECUTIVE SUMMARY =================
      h1("Executive Summary", "2"),
      p("The underlying demand is genuine and well-documented: India's mechanization gap is structural, not cyclical. But \u201cpeople need this\u201d is not the same claim as \u201cpeople will pay a marketplace fee for this, repeatedly, instead of going around it.\u201d This report's central finding is that the business's hardest problem is not customer acquisition \u2014 it is retention and fee-capture in a market built on informal, cash-based, trust-driven relationships that are easy to disintermediate."),
      p("The recommendation is not to abandon the idea, but to treat the next 30\u201360 days as a test of the business model itself \u2014 specifically, whether owners will keep paying a commission after the first booking \u2014 rather than only testing whether farmers will book at all."),

      // ================= BUSINESS MODEL CANVAS =================
      h1("Business Model Canvas", "3"),
      table([3030,3030,3020],[
        new TableRow({children:[headerCell("Customer Segments",3030), headerCell("Value Propositions",3030), headerCell("Channels",3020)]}),
        new TableRow({children:[bodyCell(["Small/marginal farmers, <2 ha","Medium farmers/contractors with idle equipment"],3030,{zebra:true,multiline:true}), bodyCell(["On-time, fairly-priced machinery access","Incremental income on idle assets"],3030,{zebra:true,multiline:true}), bodyCell(["Village agents","Word-of-mouth","WhatsApp Business"],3020,{zebra:true,multiline:true})]}),
        new TableRow({children:[headerCell("Customer Relationships",3030), headerCell("Revenue Streams",3030), headerCell("Key Resources",3020)]}),
        new TableRow({children:[bodyCell(["Human dispatcher (trust broker)","Repeat-season relationship"],3030,{multiline:true}), bodyCell(["8\u201312% commission per booking (owner-paid)"],3030,{multiline:true}), bodyCell(["Dispatcher(s)","Verified operator network","Village agent relationships"],3020,{multiline:true})]}),
        new TableRow({children:[headerCell("Key Activities",3030), headerCell("Key Partners",3030), headerCell("Cost Structure",3020)]}),
        new TableRow({children:[bodyCell(["Manual matching/dispatch","Operator verification","Owner & farmer recruitment"],3030,{zebra:true,multiline:true}), bodyCell(["Village agents","Possible FPO partnerships","Insurance partner (later)"],3030,{zebra:true,multiline:true}), bodyCell(["Dispatcher salary/time","Agent incentives","Verification costs"],3020,{zebra:true,multiline:true})]}),
      ]),

      // ================= REVENUE & PRICING =================
      h1("Revenue & Pricing Strategy", "4"),
      p("Single revenue line: commission on GTV, paid by the supply side. This is the right party to charge (farmers are more price-sensitive and have a free government alternative), but the rate itself is unvalidated."),
      table([3000,3040,3040],[
        new TableRow({children:[headerCell("Price point to test",3000), headerCell("Owner-side logic",3040), headerCell("Risk",3040)]}),
        new TableRow({children:[bodyCell("6\u20138%",3000,{zebra:true,bold:true}), bodyCell("Lower friction to first listing, easier to win initial supply",3040,{zebra:true,multiline:true}), bodyCell("May be too thin to cover dispatcher cost per booking",3040,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("8\u201312%",3000,{bold:true}), bodyCell("Matches stated hypothesis; comparable to other rental marketplaces",3040,{multiline:true}), bodyCell("Untested whether owners tolerate this after first match",3040,{multiline:true})]}),
        new TableRow({children:[bodyCell("12%+",3000,{zebra:true,bold:true}), bodyCell("Improves unit economics fastest if it holds",3040,{zebra:true,multiline:true}), bodyCell("Highest disintermediation risk \u2014 owners most likely to go around it",3040,{zebra:true,multiline:true})]}),
      ]),
      p("Recommendation: launch at the lower end of the range (6\u20138%) during the pilot to remove price objection as a variable, and measure repeat-booking-through-platform rate before ever raising it.", {italic:true}),

      // ================= GTM STRATEGY =================
      h1("Go-To-Market Strategy", "5"),
      bullet("Phase 1 \u2014 Single district: win density before brand. Recruit 5\u201310 equipment owners and run real, paid bookings with one human dispatcher."),
      bullet("Phase 2 \u2014 Trust compounding: use the first 15\u201320 successful bookings as the word-of-mouth engine \u2014 no paid acquisition until organic referral rate is measured."),
      bullet("Phase 3 \u2014 Adjacent district expansion: only after Phase 1 proves owners keep paying the commission on repeat bookings, not just the first one."),
      bullet("Distribution channel priority: village agents > word-of-mouth > WhatsApp Business presence > (much later) any app-store/digital channel."),

      // ================= CUSTOMER ACQUISITION =================
      h1("Customer Acquisition Strategy", "6"),
      table([2300,6780],[
        new TableRow({children:[headerCell("Channel",2300), headerCell("Role & Cost Profile",6780)]}),
        new TableRow({children:[bodyCell("Village agents",2300,{zebra:true,bold:true}), bodyCell("Primary channel \u2014 low cash cost, high trust, slow to scale; pay small per-booking referral incentive",6780,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Word-of-mouth",2300,{bold:true}), bodyCell("Free but entirely dependent on flawless first-use experience \u2014 the real growth engine if it works",6780,{multiline:true})]}),
        new TableRow({children:[bodyCell("Mystery-shop & direct outreach",2300,{zebra:true,bold:true}), bodyCell("Used to recruit initial equipment-owner supply directly, not farmers",6780,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Govt./FPO partnerships",2300,{bold:true}), bodyCell("Longer-term, low-cost distribution if Farmer Producer Organizations can be co-opted rather than competed with",6780,{multiline:true})]}),
      ]),

      // ================= FIRST 100 USERS =================
      h1("First 100 Users Plan", "7"),
      table([1200,7880],[
        new TableRow({children:[headerCell("Stage",1200,{align:AlignmentType.CENTER}), headerCell("Plan",7880)]}),
        new TableRow({children:[bodyCell("Wk 1\u20132",1200,{zebra:true,bold:true,align:AlignmentType.CENTER}), bodyCell("25\u201330 farmer + 10\u201315 owner interviews to confirm willingness to pay and list",7880,{zebra:true})]}),
        new TableRow({children:[bodyCell("Wk 2",1200,{bold:true,align:AlignmentType.CENTER}), bodyCell("Recruit and verify 5\u201310 equipment owners as initial supply",7880)]}),
        new TableRow({children:[bodyCell("Wk 3",1200,{zebra:true,bold:true,align:AlignmentType.CENTER}), bodyCell("Run 15+ real, paid bookings through the WhatsApp/call dispatcher in one village/cluster",7880,{zebra:true})]}),
        new TableRow({children:[bodyCell("Wk 4+",1200,{bold:true,align:AlignmentType.CENTER}), bodyCell("Convert word-of-mouth referrals to grow from ~30 to 100 real, paying users within the district",7880)]}),
      ]),
      p("The goal of the first 100 users is not vanity adoption \u2014 it's proof that at least 25% of them book a second time through the platform rather than going direct to the same owner.", {italic:true}),

      // ================= COMPETITIVE POSITION & MOAT =================
      h1("Competitive Position & Moat", "8"),
      p("There is currently no defensible moat. Trringo has OEM capital and brand trust; EM3 has a VC-funded head start and a broader FaaS bundle; government CHCs are free. The only realistic moat available to a new entrant is execution-based and earned over time:"),
      bullet("District-level supply density \u2014 having more verified, reliable equipment available faster than anyone else in one specific area."),
      bullet("A verified-operator trust layer \u2014 weak industry-wide, and the most plausible wedge given how much trust drives this category."),
      bullet("Deep village-agent relationships \u2014 slow to build, but also slow for a larger competitor to replicate cheaply."),
      p("None of this exists yet. It is a hypothesis about where a moat could be built, not a current advantage.", {italic:true}),

      // ================= REVERSE SWOT =================
      h1("Reverse SWOT Analysis", "9"),
      p("A reverse SWOT looks for the hidden flip side of each standard quadrant \u2014 where a strength conceals a risk, and a threat conceals an opportunity.", {italic:true}),
      table([2300,6780],[
        new TableRow({children:[headerCell("Quadrant",2300), headerCell("The Hidden Flip Side",6780)]}),
        new TableRow({children:[bodyCell("Strength \u2192 hidden weakness",2300,{zebra:true,bold:true,multiline:true}), bodyCell("Real, severe problem (Strength) makes it easy to mistake \u201cpeople need this\u201d for \u201cpeople will pay a recurring fee for this\u201d \u2014 the actual unvalidated claim.",6780,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Weakness \u2192 hidden strength",2300,{bold:true,multiline:true}), bodyCell("No app, no funding, no team (Weakness) forces a cheap, manual, district-first test \u2014 exactly the right-sized experiment for this stage, not a compromise.",6780,{multiline:true})]}),
        new TableRow({children:[bodyCell("Opportunity \u2192 hidden threat",2300,{zebra:true,bold:true,multiline:true}), bodyCell("Large addressable market (Opportunity) invites premature multi-state ambition \u2014 the real threat is expanding before the disintermediation question is answered in even one district.",6780,{zebra:true,multiline:true})]}),
        new TableRow({children:[bodyCell("Threat \u2192 hidden opportunity",2300,{bold:true,multiline:true}), bodyCell("Free government CHCs (Threat) are also inconsistent and slow \u2014 a partnership or white-label layer for CHCs/FPOs could turn the biggest competitor into a distribution partner instead.",6780,{multiline:true})]}),
      ]),

      // ================= INVESTOR ONE-LINER & PITCH =================
      h1("Investor One-Liner & 30-Second Pitch", "10"),
      h2("Investor one-liner"),
      p("\u201cA trust-first, WhatsApp-native marketplace bringing affordable mechanization to India's 125 million smallholder farmers, monetized through a per-booking commission on idle farm equipment.\u201d", {italic:true}),
      h2("30-second founder pitch"),
      p("\u201cEighty-six percent of India's farmers can't afford a tractor, and the apps and government programs that exist today still leave most of them underserved. We're building a WhatsApp-first booking layer that connects them directly with nearby equipment owners who have idle machinery \u2014 starting with one district, a human dispatcher, and a simple commission model, so we can prove farmers will book and owners will keep paying before we build anything more complex.\u201d", {italic:true}),

      // ================= FOUNDER ACTION SHEET =================
      h1("Founder Action Sheet \u2014 Top 10 Actions", "11"),
      table([600,8380],[
        new TableRow({children:[headerCell("#",600,{align:AlignmentType.CENTER}), headerCell("Action",8380)]}),
        ...[
          "Pick one pilot district and commit to it for the full 30\u201360 day test \u2014 resist the urge to spread thin",
          "Run 25\u201330 farmer interviews focused on actual past spend, not hypothetical interest",
          "Run 10\u201315 equipment-owner interviews testing reaction to a real commission rate, not a hypothetical one",
          "Launch at the lowest tested commission rate (6\u20138%) to remove price as a pilot variable",
          "Track every booking's source: first-match vs. repeat-through-platform vs. suspected disintermediation",
          "Build one simple anti-disintermediation lever (e.g., owner incentive for booking through platform, fast payment, dispute protection)",
          "Recruit and verify 5\u201310 equipment owners as initial pilot supply",
          "Run 15+ real, paid bookings and measure the 25%+ repeat-through-platform target explicitly",
          "Calculate true dispatcher cost per booking against commission earned \u2014 confirm unit economics are positive before any hiring",
          "Make the Go/No-Go call on raising capital or expanding districts based on the repeat-and-retention data, not on booking count alone",
        ].map((t,i)=> new TableRow({children:[bodyCell(String(i+1),600,{align:AlignmentType.CENTER,zebra:i%2===0,bold:true}), bodyCell(t,8380,{zebra:i%2===0})]})),
      ]),

      // ================= INVESTMENT SCORECARD =================
      h1("Investment Scorecard (0\u2013100)", "12"),
      table([2600,1500,5380],[
        new TableRow({children:[headerCell("Score",2600), headerCell("Value",1500,{align:AlignmentType.CENTER}), headerCell("Reasoning",5380)]}),
        new TableRow({children:[bodyCell("Business Viability",2600,{zebra:true,bold:true}), bodyCell("45",1500,{zebra:true,align:AlignmentType.CENTER,color:GOLD,bold:true}), bodyCell("Real demand and a workable asset-light model, but disintermediation risk is structural, not incidental",5380,{zebra:true})]}),
        new TableRow({children:[bodyCell("Revenue Potential",2600,{bold:true}), bodyCell("38",1500,{align:AlignmentType.CENTER,color:RED,bold:true}), bodyCell("Take-rate squeezed between a free government alternative and a high disintermediation risk on the supply side",5380)]}),
        new TableRow({children:[bodyCell("GTM Strength",2600,{zebra:true,bold:true}), bodyCell("50",1500,{zebra:true,align:AlignmentType.CENTER,color:GOLD,bold:true}), bodyCell("Cheap, plausible hyperlocal channel, but inherently slow and dispatcher-dependent to scale",5380,{zebra:true})]}),
        new TableRow({children:[bodyCell("Competitive Strength",2600,{bold:true}), bodyCell("30",1500,{align:AlignmentType.CENTER,color:RED,bold:true}), bodyCell("No moat exists yet against an OEM-backed leader, a VC-funded challenger, and a free government option",5380)]}),
        new TableRow({children:[bodyCell("Investor Readiness",2600,{zebra:true,bold:true}), bodyCell("25",1500,{zebra:true,align:AlignmentType.CENTER,color:RED,bold:true}), bodyCell("Pre-revenue, idea-stage, no pilot data \u2014 not fundable in current form regardless of market size",5380,{zebra:true})]}),
        new TableRow({children:[bodyCell("Average",2600,{bold:true}), bodyCell("37.6",1500,{align:AlignmentType.CENTER,color:RED,bold:true}), bodyCell("Below the threshold most early-stage investors would engage with \u2014 pilot data is the unlock, not a better deck",5380,{bold:true})]}),
      ]),

      // ================= VISUAL DASHBOARD =================
      h1("Visual Dashboard", "13"),
      img("dashboard.png", 560, 700),
      caption("One-page visual summary: business model, revenue streams, GTM flow, first-100-users plan, competitive moat, key risks, scorecard, and final verdict."),

      // ================= SUSTAINABILITY VERDICT =================
      h1("Sustainability Verdict", "14"),
      tag("VALIDATE \u2014 Real Problem, Unproven Business Model", GOLD, NAVY_DARK),
      p("This is not yet a sustainable business \u2014 it is a well-documented problem paired with an unproven revenue mechanism. The mechanization gap is real, but the commission model rests on owners not disintermediating the platform after the first match, and no evidence yet exists either way. Sustainability hinges on one specific, testable number: the percentage of bookings that happen a second time through the platform rather than directly between the same farmer and owner \u2014 everything else in this report is downstream of that single metric."),
    ],
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/strategy/Business_Strategy_Report.docx", buffer);
  console.log("done");
});
